/* UAS PRAKTIKUM DASPRO KALKULATOR DALAM BAHASA C
Nama : Viktris Maria Kristriani Lubis
NIM  : 11S22041 */

#include <stdio.h>
#include <math.h>
#include <stdarg.h>
#include <stdbool.h>

typedef struct {
    char operator;
    double operands[100];
    int numOperands;
    double angka1;
    double angka2;
    char darisuhu;
    char kesuhu;
} Operation;

//penjumlahan (+)
double penjumlahan(double angka1, double angka2) {
    return angka1 + angka2;
}

//pengurangan (-)
double pengurangan(double angka1, double angka2) {
    return angka1 - angka2;
}

//perkalian (*)
double perkalian(double angka1, double angka2) {
    return angka1 * angka2;
}

//pembagian (/)
double pembagian(double angka1, double angka2) {
    return angka1 / angka2;
}

//pangkat (^)
double pangkat(double angka1, double angka2) {
    return pow(angka1, angka2);
}

//akar (a)
double akar(double angka) {
    return sqrt(angka);
}

//sin (s)
double sinus(double angka) {
    return sin(angka);
}

//cos (c)
double cosinus(double angka) {
    return cos(angka);
}

//tan (t)
double tangen(double angka) {
    return tan(angka);
}

//sec (S)
double secant(double angka) {
    return 1 / cos(angka);
}

//cot (T)
double cotangent(double angka) {
    return cos(angka) / sin(angka);
}

//csc (O)
double cosecant(double angka) {
    return 1 / sin(angka);
}

// arc sin (U)
double arcsin(double angka) {
    return asin(angka);
}

// arc cos (V)
double arccos(double angka) {
    return acos(angka);
}

// arc tan (W)
double arctan(double angka) {
    return atan(angka);
}

// arc sec (X)
double arcsec(double angka) {
    return acos(1 / angka);
}

// arccsc (Y)
double arccsc(double angka) {
    return asin(1 / angka);
}

// arc cot (Z)
double arccot(double angka) {
    return atan(1 / angka);
}

//ln (N)
double natural_log(double angka) {
    return log(angka);
}

//log (L)
double logarithma(double angka) {
    return log10(angka);
}

//konversi suhu (I)
double konversisuhu(double suhu, char darisuhu, char kesuhu) {
    if (darisuhu == 'C') {
        if (kesuhu == 'F') {
            return (suhu * 9 / 5) + 32;  // Celsius ke Fahrenheit
        } else if (kesuhu == 'K') {
            return suhu + 273.15;  // Celsius ke Kelvin
        } else if (kesuhu == 'R') {
            return (suhu * 4/5); // Celsius ke Reaumur
        }
    } else if (darisuhu == 'F') {
        if (kesuhu == 'C') {
            return (suhu - 32) * 5 / 9;  // Fahrenheit ke Celsius
        } else if (kesuhu == 'K') {
            return (suhu + 459.67) * 5 / 9;  // Fahrenheit ke Kelvin
        } else if (kesuhu == 'R'){
            return (suhu - 32) * 4/9; // Fahrenheit ke Reaumur
        }
    } else if (darisuhu == 'K') {
        if (kesuhu == 'C') {
            return suhu - 273.15;  // Kelvin ke Celsius
        } else if (kesuhu == 'F') {
            return (suhu * 9 / 5) - 459.67;  // Kelvin ke Fahrenheit
        } else if (kesuhu == 'R'){
            return (suhu - 273.15) * 4/5; // Kelvin ke reaumur
        }
    } else if (darisuhu == 'R'){
        if (kesuhu == 'C'){
            return (suhu *5/4);   //Reaumur ke Celcius 
        } else if (kesuhu == 'F'){
            return (suhu *9/4) + 32;   //Reaumur ke Fahrenheit
        } else if (kesuhu == 'K'){
            return (suhu *5/4) + 273.15;   //Reaumur ke Kelvin
        }
    }

    printf("Unit suhu tidak valid.\n");
    return 0;
}

double calculate(Operation operation) {
    double result;

    switch (operation.operator) {
        case '+':
              result = 0;
            for (int i = 0; i < operation.numOperands; i++) {
                result += operation.operands[i];
            }
            break;
        case '-':
            result = operation.operands[0]; 
            for (int i = 1; i < operation.numOperands; i++) {
                result -= operation.operands[i];
            }
            break;
        case '*':
            result = operation.operands[0]; 
            for (int i = 1; i < operation.numOperands; i++) {
                result *= operation.operands[i];
            }
            break;
        case '/':
           result = operation.operands[0]; 
            for (int i = 1; i < operation.numOperands; i++) {
                result /= operation.operands[i];
            }
            break;
        case '^':
            result = operation.operands[0]; 
            for (int i = 1; i < operation.numOperands; i++) {
            result = pow(result, operation.operands[i]);
            }
            break;
        case 'a':
            result = akar(operation.angka1);
            break;
        case 's':
            result = sinus(operation.angka1);
            break;
        case 'c':
            result = cosinus(operation.angka1);
            break;
        case 't':
            result = tangen(operation.angka1);
            break;
        case 'S':
            result = secant(operation.angka1);
            break;
        case 'O': 
            result = cotangent(operation.angka1);
            break;
        case 'T':
            result = cosecant(operation.angka1);
            break;
        case 'U':
            result = arcsin(operation.angka1);
            break;
        case 'V':
            result = arccos(operation.angka1);
            break;
        case 'W':
            result = arctan(operation.angka1);
            break;
        case 'X':
            result = arcsec(operation.angka1);
            break;
        case 'Y':
            result = arccsc(operation.angka1);
            break;
        case 'Z':
            result = arccot(operation.angka1);
            break;
        case 'N':
            result = natural_log(operation.angka1);
            break;
        case 'L':
            result = logarithma(operation.angka1);
            break;
        case 'I':
            result = konversisuhu(operation.angka1, operation.darisuhu, operation.kesuhu);
            break;
        default:
            printf("Operator tidak valid.\n");
            return 0;
    }
    return result;
}

bool wantsToContinue() {
    char choice;
    printf("\nApakah Anda masih ingin melakukan operasi (y/n)? ");
    scanf(" %c", &choice);
    getchar(); // Menggunakan getchar() untuk membersihkan karakter newline ('\n') dari input sebelumnya

    if (choice == 'n' || choice == 'N') {
        printf("\n=== PROSES TELAH BERHENTI, SAMPAI JUMPA ====\n");
        return false;
    } else {
        return true;
    }
}
int moduloInt(int dividend, int divisor) {
    return dividend % divisor;
}


int main() {
 do {
    int numOperations;
    printf("=========================================================\n");
    printf("|\t\t\t\t\t\t\t\t\t\t\t\t\t\t|\n");
    printf("|\t\tUAS PRAKTIKUM DASPRO KALKULATOR DALAM BAHASA C\t|\n");
    printf("|\t\tNama : Viktris Maria Kristriani Lubis\t\t\t|\n");
    printf("|\t\tNIM  : 11S22041\t\t\t\t\t\t\t\t\t|\n");
    printf("|\t\t\t\t\t\t\t\t\t\t\t\t\t\t|\n");
    printf("=========================================================\n");
    printf("\n");
    printf("Selamat datang di Kalkulator dalam bahasa C!\n");
    printf("\n");
    printf("Masukkan jumlah operasi yang ingin dilakukan: ");
    scanf("%d", &numOperations);
    printf("=========================================================\n");
    Operation operations[numOperations];

    for (int i = 0; i < numOperations; i++) {
        printf("\nOperasi ke-%d\n", i + 1);
        printf("Silahkan Pilih operasi!\n");
        printf("+ = Penjumlahan\n");
        printf("- = Pengurangan\n");
        printf("* = Perkalian\n");
        printf("/ = Pembagian\n");
        printf("^ = Pangkat\n");
        printf("a = Akar\n");
        printf("s = sinus\n");
        printf("c = Cosinus\n");
        printf("t = Tangen\n");
        printf("S = Secant\n");
        printf("O = Cotangent\n");
        printf("T = Cosecant\n");
        printf("U = Arcsin\n");
        printf("V = Arccos\n");
        printf("W = Arctan\n");
        printf("X = Arcsec\n");
        printf("Y = Arccsc\n");
        printf("Z = Arccot\n");
        printf("N = Natural Log\n");
        printf("L = Logarithma\n");
        printf("I = Konversi Suhu\n");
        printf("Pilih Operasi : ");
        scanf(" %c", &operations[i].operator);
        printf("=========================================================\n");

        if (operations[i].operator != 'a' && operations[i].operator != 's' && 
            operations[i].operator != 'c' && operations[i].operator != 't' && 
            operations[i].operator != 'S' && operations[i].operator != 'O' &&
            operations[i].operator != 'T' && operations[i].operator != 'U' && 
            operations[i].operator != 'V' && operations[i].operator != 'W' &&
            operations[i].operator != 'X' && operations[i].operator != 'Y' && 
            operations[i].operator != 'Z' && operations[i].operator != 'N' && 
            operations[i].operator != 'L' && operations[i].operator != 'I' ) {
    
            printf("=== PENJUMALAHAN ====:\n ");
            printf("Masukkan jumlah operan: ");
            scanf("%d", &operations[i].numOperands);
            for (int j = 0; j < operations[i].numOperands; j++) {
            printf("Masukkan operan %d: ", j + 1);
            scanf("%lf", &operations[i].operands[j]);}
            
        } else if (operations[i].operator == '-') {
            printf("=== PENGURANGAN ====:\n ");
            printf("Masukkan jumlah operan: ");
            scanf("%d", &operations[i].numOperands);
    
        for (int j = 0; j < operations[i].numOperands; j++) {
            printf("Masukkan operan %d: ", j + 1);
            scanf("%lf", &operations[i].operands[j]);}   
            
        } else if (operations[i].operator == '*') {
            printf("=== PERKALIAN ====:\n ");
            printf("Masukkan jumlah operan: ");
            scanf("%d", &operations[i].numOperands);
        
        for (int j = 0; j < operations[i].numOperands; j++) {
            printf("Masukkan operan %d: ", j + 1);
            scanf("%lf", &operations[i].operands[j]);}
            
        } else if (operations[i].operator == '/') {
            printf("=== PEMBAGIAN ====:\n ");
            printf("Masukkan jumlah operan: ");
            scanf("%d", &operations[i].numOperands);
        
        for (int j = 0; j < operations[i].numOperands; j++) {
            printf("Masukkan operan %d: ", j + 1);
            scanf("%lf", &operations[i].operands[j]);}
            
        } else if (operations[i].operator == '^') {
            printf("=== PANGKAT ====:\n ");
            printf("Masukkan jumlah operan: ");
            scanf("%d", &operations[i].numOperands);
            
        for (int j = 0; j < operations[i].numOperands; j++) {
            printf("Masukkan operan %d: ", j + 1);
            scanf("%lf", &operations[i].operands[j]);}
            
        } else if (operations[i].operator == 'I') {
            printf("=== SUHU ====:\n ");
            printf("Masukkan suhu: ");
            scanf("%lf", &operations[i].angka1);
            printf("Masukkan unit suhu awal (C, F, K, R): ");
            scanf(" %c", &operations[i].darisuhu);
            printf("Masukkan unit suhu tujuan (C, F, K, R): ");
            scanf(" %c", &operations[i].kesuhu);
        } else {
            printf("Masukkan operand: ");
            scanf("%lf", &operations[i].angka1);
        }
    }

    printf("\n Hasil operasi:\n");
    for (int i = 0; i < numOperations; i++) {
        double result = calculate(operations[i]);
        printf("Operasi %d: %g\n", i+1, result);
       printf("=== PROSES SELESAI ====:\n ");
    }   
  } while (wantsToContinue());
    return 0;
}